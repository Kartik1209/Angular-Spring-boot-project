package com.example.agriculturalApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgriculturalAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
