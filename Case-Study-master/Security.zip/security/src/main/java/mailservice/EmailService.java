package mailservice;

public class EmailService {

}
