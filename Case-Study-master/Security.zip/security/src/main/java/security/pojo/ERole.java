package security.pojo;

public enum ERole {
	 ROLE_USER,
	 ROLE_ADMIN,
	 ROLE_ATTENDEE
}